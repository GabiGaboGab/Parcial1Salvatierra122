package gremioaventurerosparcial;

import java.util.ArrayList;
import java.util.List;

public class GremioAventurerosParcial {

    public static void main(String[] args) {
        GremioAventureros gremio = new GremioAventureros("Eldoria", new ArrayList<>());
        try {
            gremio.agregarAventurero(new Guerrero("G-01", "Arin", Rango.ORO, 30));
            gremio.agregarAventurero(new Mago("M-02", "Lyra", Rango.PLATA, 45));
            gremio.agregarAventurero(new Arquero("A-03", "Nox", Rango.BRONCE, 18));
            gremio.agregarAventurero(new Guerrero("G-04", "Borin", Rango.PLATA, 20));
            gremio.agregarAventurero(new Mago("G-01", "Arin", Rango.BRONCE, 99));
        } catch (AventureroRepetidoException a) {
            System.out.println("No se puede agregar" + a.getMessage());
        }

        System.out.println("Aventureros registrados:");
        mostrarAventureros(gremio.obtenerAventureros());
        System.out.println("\nAtaques:");
        mostrarAtaques(gremio.obtenerAventureros());
        System.out.println("\nEntrenamientos:");
        mostrarEntrenamientos(gremio.obtenerAventureros());
        System.out.println("\nPoder de combate:");
        mostrarPoderes(gremio.obtenerAventureros());
        System.out.println("\nAventureros de rango PLATA:");
        mostrarAventureros(gremio.filtrarPorRango(Rango.PLATA));
        System.out.println("\nAventureros con poder >= 55:");
        mostrarAventureros(gremio.obtenerAventurerosPoderosos(55));

    }

    /**
     * Muestra en pantalla a todos los aventureros registrados en el gremio.
     *
     * @param aventureros (List<Aventurero>) Lista de aventureros a ser
     * recorrida.
     */
    private static void mostrarAventureros(List<Aventurero> aventureros) {
        for (Aventurero a : aventureros) {
            System.out.println(a);
        }
    }

    /**
     * Muestra como ataca cada aventurero.
     *
     * @param aventureros (List<Aventurero>) Lista de los aventureros que
     * atacaran.
     */
    private static void mostrarAtaques(List<Aventurero> aventureros) {
        for (Aventurero aven : aventureros) {
            if (aven instanceof Atacante atac) {
                System.out.println(atac.atacar());
            }
        }
    }

    /**
     * Muestra de que manera entrena cada aventurero.
     *
     * @param aventureros (List<Aventurero>) Lista de los aventureros que
     * entrenaran.
     */
    private static void mostrarEntrenamientos(List<Aventurero> aventureros) {
        for (Aventurero aven : aventureros) {
            if (aven instanceof Entrenable ent) {
                System.out.println(ent.entrenar());
            }
        }
    }

    /**
     * Mostrara el nivel de poder que tiene cada aventurero en el gremio.
     * 
     * @param aventureros (List<Aventurero>) Lista de los aventureros que
     * mostraran su nivel poder.
     */
    private static void mostrarPoderes(List<Aventurero> aventureros) {
        for (Aventurero a : aventureros) {
            System.out.println("Aventurero: " + a.getNombre() + "| Poder: " + a.calcularPoder());
        }
    }

}

package gremioaventurerosparcial;

public interface Atacante {

    /**
     * Muestra como ataca cada aventurero.
     *
     * @return (String) retorna un mensaje del aventurero atacando.
     */
    String atacar();
}

package gremioaventurerosparcial;

public class Arquero extends Aventurero implements Entrenable, Atacante {

    private final int PRECISION_BONIFICACION = 3;
    private final int valPrecision;

    /**
     * Datos del arquero registrado en el gremio
     *
     * @param codIdent (String) Codigo identificador unico para cada aventurero.
     * @param nombre (String) El nombre que recibira el aventurero
     * @param rango (Rango) El rango que tiene cada aventurero.
     * @param valPrecision (int) precision que tiene el arquero.
     */
    public Arquero(String codIdent, String nombre, Rango rango, int valPrecision) {
        super(codIdent, nombre, rango);
        validarPositivo(valPrecision, "La precision no puede ser menor o igual a 0.");
        this.valPrecision = valPrecision;
    }

    /**
     * Valor de precision que tiene un arquero
     *
     * @return (int) devuelve la precision del arquero.
     */
    public int getValPrecision() {
        return valPrecision;
    }

    /**
     * Muestra como entrena un arquero.
     *
     * @return (String) Mensaje del arquero entrenando
     */
    @Override
    public String entrenar() {
        return "El arquero: " + getNombre() + " esta entrenando.";
    }

    /**
     * Muestra como un arquero ataca.
     *
     * @return (String) Mensaje del arquero atacando.
     */
    @Override
    public String atacar() {
        return "El arquero:" + getNombre() + " saca una flecha del carcaj y dispara.";
    }

    /**
     * Deja obtener la precision, con la bonificacion incluida, del arquero.
     *
     * @return (int) Precision completa.
     */
    @Override
    public int calcularPoder() {
        return valPrecision * PRECISION_BONIFICACION;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("Precisión: ").append(valPrecision);
        return sb.toString();
    }

}

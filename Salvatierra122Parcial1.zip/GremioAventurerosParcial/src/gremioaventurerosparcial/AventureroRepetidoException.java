package gremioaventurerosparcial;

public class AventureroRepetidoException extends RuntimeException {

    private static final String MESSAGE = "Ese aventurero ya se encuentra en el gremio.";

    /**
     * Excepcion que se usa cuando se encuentra un aventurero repetido.
     */
    public AventureroRepetidoException() {
        super(MESSAGE);
    }

    /**
     * Excepcion que se usa cuando se encuentra un aventurero repetido
     * con un mensaje personalizado.
     * 
     * @param mensaje (String) mensaje personalizado.
     */
    public AventureroRepetidoException(String mensaje) {
        super(mensaje);
    }

}

package gremioaventurerosparcial;

public class Mago extends Aventurero implements Atacante {

    private final int MANA_BONIFICACION = 10;
    private final int puntosMana;

    /**
     * Datos del mago registrado en el gremio
     *
     * @param codIdent (String) Codigo identificador unico para cada aventurero.
     * @param nombre (String) El nombre que recibira el aventurero
     * @param rango (Rango) El rango que tiene cada aventurero.
     * @param puntosMana (int) puntos de mana que tiene el mago.
     */
    public Mago(String codIdent, String nombre, Rango rango, int puntosMana) {
        super(codIdent, nombre, rango);
        validarPositivo(puntosMana, "La mana no puede ser menor o igual a 0.");
        this.puntosMana = puntosMana;
    }

    /**
     * Valor de fuerza que tiene un mago
     *
     * @return (int) devuelve la fuerza del mago.
     */
    public int getPuntosMana() {
        return puntosMana;
    }

    /**
     * Muestra como un mago ataca.
     *
     * @return (String) Mensaje del mago atacando.
     */
    @Override
    public String atacar() {
        return "El mago:" + getNombre() + " lanza hechizos";
    }

    /**
     * Deja obtener el mana, con la bonificacion incluida, del guerrero.
     *
     * @return (int) mana completo.
     */
    @Override
    public int calcularPoder() {
        return puntosMana + MANA_BONIFICACION;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("Puntos de mana: ").append(puntosMana);
        return sb.toString();
    }

}

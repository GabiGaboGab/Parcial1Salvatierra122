
package gremioaventurerosparcial;


public interface Entrenable {
    /**
     * Muestra como entrena cada aventurero.
     * 
     * @return (String) retorna un mensaje del aventurero entrenando.
     */
    String entrenar();
    
}


package gremioaventurerosparcial;


public enum Rango {
    BRONCE,
    PLATA,
    ORO;
    

    @Override
    public String toString(){
    String name = this.name();
    return name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
    }
    
}

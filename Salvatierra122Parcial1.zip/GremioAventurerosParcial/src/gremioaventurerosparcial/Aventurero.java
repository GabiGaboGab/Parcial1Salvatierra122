package gremioaventurerosparcial;

import java.util.Objects;

public abstract class Aventurero {

    private final String codIdent;
    private final String nombre;
    private final Rango rango;

    /**
     * Aventurero que sera registrado en el gremio.
     *
     * @param codIdent (String) Codigo identificador unico para cada aventurero.
     * @param nombre (String) El nombre que recibira el aventurero
     * @param rango (Rango) El rango que tiene cada aventurero.
     */
    public Aventurero(String codIdent, String nombre, Rango rango) {
        validarString(nombre, "Nombre no ingresado");
        validarString(codIdent, "Código no ingresado");
        if (rango == null) {
            throw new IllegalArgumentException("Rango no ingresado");
        }
        this.codIdent = codIdent;
        this.nombre = nombre;
        this.rango = rango;
    }

    /**
     * Valida cadenas de texto para que no se filtren textos nulos y vacios.
     *
     * @param texto (String) texto a ser validado por el metodo.
     * @param msg (String) mensaje que se mostrara cuando se arroje la
     * exception.
     */
    protected static void validarString(String texto, String msg) {

        if (texto == null || texto.isBlank()) {
            throw new IllegalArgumentException(msg);
        }

    }

    /**
     * Valida enteros para que no se filtren numeros negativos.
     *
     * @param dato (int) entero a ser validado por el metodo.
     * @param msg (String) mensaje que se mostrara cuando se arroje la
     * exception.
     */
    protected static void validarPositivo(int dato, String msg) {

        if (dato <= 0) {
            throw new IllegalArgumentException("no debe ser menor a cero");
        }

    }

    /**
     * Calcula el nivel de poder de cada aventurero.
     *
     * @return (int) El nivel de poder ya calculado.
     */
    public abstract int calcularPoder();

    /**
     * Permite obtener el codigo de identificacion.
     *
     * @return (String) el codigo de identificacion.
     */
    public String getCodIdent() {
        return codIdent;
    }

    /**
     * Permite obtener el nombre.
     *
     * @return (String) el nombre del aventurero.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Permite obtener el rango.
     *
     * @return (Rango) el rango del aventurero.
     */
    public Rango getRango() {
        return rango;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        sb.append("Nombre: ").append(nombre);
        sb.append("Codigo de identificación: ").append(codIdent);
        sb.append("Rango: ").append(rango);
        return sb.toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(codIdent, nombre);

    }

    @Override
    public boolean equals(Object o) {

        if (this == o) {
            return true;
        }

        if (!(o instanceof Aventurero a)) {
            return false;
        }

        return codIdent.equals(a.codIdent) && nombre.equals(a.nombre);
    }

}

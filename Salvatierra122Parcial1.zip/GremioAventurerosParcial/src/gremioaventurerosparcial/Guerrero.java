package gremioaventurerosparcial;

public class Guerrero extends Aventurero implements Entrenable, Atacante {

    private final int FUERZA_BONIFICACION = 2;
    private final int valorFuerza;

    /**
     * Datos del guerrero registrado en el gremio
     *
     * @param codIdent (String) Codigo identificador unico para cada aventurero.
     * @param nombre (String) El nombre que recibira el aventurero
     * @param rango (Rango) El rango que tiene cada aventurero.
     * @param valorFuerza (int) fuerza que tiene el guerrero.
     */
    public Guerrero(String codIdent, String nombre, Rango rango, int valorFuerza) {
        super(codIdent, nombre, rango);
        validarPositivo(valorFuerza, "La fuerza no puede ser menor o igual a 0.");
        this.valorFuerza = valorFuerza;
    }

    /**
     * Valor de fuerza que tiene un guerrero
     *
     * @return (int) devuelve la fuerza del guerrero.
     */
    public int getValorFuerza() {
        return valorFuerza;
    }

    /**
     * Muestra como entrena un guerrero.
     *
     * @return (String) Mensaje del guerrero entrenando
     */
    @Override
    public String entrenar() {
        return "El guerrero: " + getNombre() + " esta entrenando.";
    }

    /**
     * Muestra como un guerrero ataca.
     *
     * @return (String) Mensaje del guerrero atacando.
     */
    @Override
    public String atacar() {
        return "El guerrero:" + getNombre() + " usa su espada.";
    }

    /**
     * Deja obtener la fuerza, con la bonificacion incluida, del guerrero.
     *
     * @return (int) fuerza completa.
     */
    @Override
    public int calcularPoder() {
        return valorFuerza * FUERZA_BONIFICACION;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("Valor de fuerza: ").append(valorFuerza);
        return sb.toString();
    }

}

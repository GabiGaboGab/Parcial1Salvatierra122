package gremioaventurerosparcial;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class GremioAventureros {

    private final String nombre;
    private final List<Aventurero> aventureros;

    /**
     * Es el gremio que almacena a los aventureros.
     *
     * @param nombre (String) nombre que recibe el gremio.
     * @param aventureros (List<Aventurero>) lista de aventureros en el gremio.
     */
    public GremioAventureros(String nombre, List<Aventurero> aventureros) {
        validarNulo(nombre, "Debe colocar un nombre.");
        this.nombre = nombre;
        this.aventureros = aventureros;
    }

    /**
     * Obtiene a los aventureros mas poderosos.
     *
     * @param poderBuscado (int) es el nivel de poder a buscar.
     * @return (List<Aventurero>) devuelve una lista con los aventureros
     * buscados.
     */
    public List<Aventurero> obtenerAventurerosPoderosos(int poderBuscado) {
        if (poderBuscado <= 0) {
            throw new IllegalArgumentException("El poder a buscar debe ser positivo");
        }
        List<Aventurero> masPoderosos = new ArrayList<>();

        for (Aventurero a : aventureros) {
            if (a.calcularPoder() >= poderBuscado) {
                masPoderosos.add(a);
            }
        }
        return masPoderosos;
    }

    /**
     * Filtra a los aventureros del gremio por rango.
     *
     * @param rango (Rango) Rango que sera usado para filtrar.
     * @return (List<Aventurero>)Retorna una nueva lista con los aventureros
     * filtrados.
     */
    public List<Aventurero> filtrarPorRango(Rango rango) {
        Objects.requireNonNull(rango, "El rango no puede ser nulo");
        List<Aventurero> listaPorRango = new ArrayList<>();
        for (Aventurero a : aventureros) {
            if (a.getRango() == rango) {
                listaPorRango.add(a);
            }

        }
        return listaPorRango;
    }

    /**
     * Valida aventureros repetidos.
     *
     * @param a (Aventurero )aventurero a ser validado.
     */
    private void validarAventureroRepetido(Aventurero a) {
        if (aventureros.contains(a)) {
            throw new AventureroRepetidoException(
                    "Ya existe un aventurero en el gremio con los siguientes datos: " + a.getCodIdent()
                    + a.getNombre() + "."
            );
        }
    }

    /**
     * Valida que el dato ingresado no sea nulo
     *
     * @param o (Object) Dato que sera validado.
     * @param msg (String) Mensaje que se usa a la hora de arrojar la excepcion.
     */
    private void validarNulo(Object o, String msg) {
        if (o == null) {
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Agrega un nuevo aventurero al gremio.
     * 
     * @param a (Aventurero) Es el aventurero que sera añdido al gremio.
     * @throws AventureroRepetidoException Excepcion que se arroja cuando "a" 
     * ya existe dentro del gremio.
     */
    public void agregarAventurero(Aventurero a) throws AventureroRepetidoException {
        validarNulo(a, "El aventurero no puede ser nulo.");
        validarAventureroRepetido(a);

        aventureros.add(a);
    }

    /**
     * Permite obtener el nombre del gremio.
     *
     * @return (String) retorna el nombre del gremio.
     */
    public String getNombre() {
        return nombre;
    }

   /**
     * Permite obtener a todos los aventureros dentro del gremio,.
     *
     * @return (ArrayList<Aventurero>) retorna una lista con los aventureros.
     */
    public List<Aventurero> obtenerAventureros() {
        return new ArrayList<>(aventureros);
    }

}
